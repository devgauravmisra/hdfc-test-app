This is a sample app that demonstrates integration of Razorpay's Custom UI SDK for Android.

The documentation for this SDK is available here: [https://razorpay.com/docs/payment-gateway/android-integration/custom/](https://razorpay.com/docs/payment-gateway/android-integration/custom/).
